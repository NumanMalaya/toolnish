<?php
session_start();
error_reporting(E_ALL & ~E_DEPRECATED);
ini_set('display_errors', 0);

/* ---------- PhpSpreadsheet ---------- */
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;

/* ---------- DB CONNECTION ---------- */

$host = "localhost";
$user = "root";
$pass = "";
$db   = "performa";

$host = "127.0.0.1:3306";
$user = "u850285897_ToolNish";
$pass = "Numan@22244";
$db   = "u850285897_ToolNish";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("DB Connection Failed: " . $conn->connect_error);
}


/* =========================================================
   HANDLE LOGOUT
   ========================================================= */

if (isset($_POST['logout'])) {

    // Destroy current login session
    session_unset();
    session_destroy();

    // Start a new session so we can remember
    // that this visitor intentionally logged out
    session_start();

    $_SESSION['auto_login_disabled'] = true;

    // Refresh page
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}


/* =========================================================
   HANDLE MANUAL LOGIN
   ========================================================= */

$loginError = "";

if (isset($_POST['login'])) {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare(
        "SELECT userID, password, type FROM user WHERE username=?"
    );

    $stmt->bind_param("s", $username);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows === 1) {

        $row = $result->fetch_assoc();

        if ($password === $row['password']) {

            // Successful manual login
            $_SESSION['userID'] = $row['userID'];
            $_SESSION['username'] = $username;
            $_SESSION['type'] = $row['type'];

            // User manually logged in,
            // so auto-login is no longer needed
            $_SESSION['auto_login_disabled'] = false;

            // Refresh page
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();

        } else {

            $loginError = "Incorrect password!";
        }

    } else {

        $loginError = "Username not found!";
    }

    $stmt->close();
}

/* =========================================================
   CONTINUE AS "Guest"
   ========================================================= */

if (isset($_POST['continueAsGuest'])) {

    $autoUsername = "Guest";

    $stmt = $conn->prepare(
        "SELECT userID, type FROM user WHERE username=?"
    );

    $stmt->bind_param("s", $autoUsername);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows === 1) {

        $row = $result->fetch_assoc();

        $_SESSION['userID'] = $row['userID'];
        $_SESSION['username'] = $autoUsername;
        $_SESSION['type'] = $row['type'];

        // User has chosen to continue as Guest
        $_SESSION['auto_login_disabled'] = false;

        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    $stmt->close();
}


/* =========================================================
   AUTOMATIC LOGIN AS "Guest"
   ========================================================= */

if (
    !isset($_SESSION['userID']) &&
    !isset($_SESSION['auto_login_disabled'])
) {

    $autoUsername = "Guest";

    $stmt = $conn->prepare(
        "SELECT userID, password, type FROM user WHERE username=?"
    );

    $stmt->bind_param("s", $autoUsername);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows === 1) {

        $row = $result->fetch_assoc();

        // We don't actually need the password here.
        // We are intentionally using this account as the default visitor.
        $_SESSION['userID'] = $row['userID'];
        $_SESSION['username'] = $autoUsername;
        $_SESSION['type'] = $row['type'];

    }

    $stmt->close();
}


/* =========================================================
   SHOW LOGIN PAGE IF NOT LOGGED IN
   ========================================================= */

if (!isset($_SESSION['userID'])):
?>


<!DOCTYPE html>
<html>
<head>
    <title>Login - SLWMC</title>
</head>

<body style="font-family: sans-serif; background: #f0f2f5; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0;">

<form method="post" style="background:#fff; padding:30px; border-radius:12px; box-shadow:0 10px 25px rgba(0,0,0,0.1); width:320px;">

    <h2 style="text-align:center; margin-top:0;">
        Performa Login
    </h2>

    <?php if($loginError): ?>
        <p style="color:red; font-size:14px; text-align:center;">
            <?= htmlspecialchars($loginError) ?>
        </p>
    <?php endif; ?>

    <label style="display:block; margin-bottom:5px; font-size:14px;">
        Username
    </label>

    <input
        type="text"
        name="username"
        required
        placeholder="Guest"
        style="width:100%; padding:10px; margin-bottom:15px; border:1px solid #ddd; border-radius:6px; box-sizing:border-box;"
    >

    <label style="display:block; margin-bottom:5px; font-size:14px;">
        Password
    </label>

    <input
        type="password"
        name="password"
        placeholder="000"
        required
        style="width:100%; padding:10px; margin-bottom:20px; border:1px solid #ddd; border-radius:6px; box-sizing:border-box;"
    >

    <button
        type="submit"
        name="login"
        style="width:100%; padding:12px; background:#007bff; color:#fff; border:none; border-radius:6px; font-weight:bold; cursor:pointer;"
    >
        Sign In
    </button>
    
    <div style="text-align:center; margin:15px 0; color:#999;">
    OR
</div>

<button
    type="submit"
    name="continueAsGuest"
    formnovalidate
    style="
        width:100%;
        padding:12px;
        background:#6c757d;
        color:#fff;
        border:none;
        border-radius:6px;
        font-weight:bold;
        cursor:pointer;
    "
>
    Continue as Guest
</button>

</form>

</body>
</html>

<?php
exit();
endif;
?>

<?php
/* ---------- LOGGED-IN USER INFO ---------- */
$loggedInUser = $_SESSION['userID'];
$loggedInType = $_SESSION['type'];

/* ---------- HANDLE EXCEL UPLOAD ---------- */
$uploadMessage = "";
$uploadMessageColor = "green";

if (isset($_POST['uploadExcel']) && isset($_FILES['excelFile']['tmp_name'])) {
    try {
        $file = $_FILES['excelFile']['tmp_name'];
        $spreadsheet = IOFactory::load($file);
        $sheet = $spreadsheet->getActiveSheet();
        $data = $sheet->toArray();

        $requiredColumns = ['bookNo','serialNo','date','tehsil','pointName','latLong','time','vehicleType','vehicleNo','wasteType'];
        $header = array_map('trim', $data[0]);
        $headerMap = [];
        foreach ($header as $index => $colName) { $headerMap[strtolower($colName)] = $index; }

        $inserted = 0; $skipped = 0;
        foreach ($data as $key => $row) {
            if ($key == 0) continue;
            $tehsil = trim($row[$headerMap['tehsil']] ?? '');
            if ($loggedInType !== 'admin' && strtolower($tehsil) !== strtolower($_SESSION['username'])) { $skipped++; continue; }

            $serialNo = trim($row[$headerMap['serialno']] ?? '');
            $dateRaw  = trim($row[$headerMap['date']] ?? '');
            if (empty($serialNo) || empty($dateRaw)) continue;
            $date = date("Y-m-d", strtotime($dateRaw));

            $checkStmt = $conn->prepare("SELECT 1 FROM tripdetail WHERE serialNo = ? AND `date` = ? AND userID = ?");
            $checkStmt->bind_param("ssi", $serialNo, $date, $loggedInUser);
            $checkStmt->execute();
            if ($checkStmt->get_result()->num_rows > 0) { $skipped++; $checkStmt->close(); continue; }
            $checkStmt->close();

            $stmt = $conn->prepare("INSERT INTO tripdetail (bookNo, serialNo, `date`, tehsil, pointName, latLong, time, vehicleType, vehicleNo, wasteType, userID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssssssi", trim($row[$headerMap['bookno']] ?? ''), $serialNo, $date, $tehsil, trim($row[$headerMap['pointname']] ?? ''), trim($row[$headerMap['latlong']] ?? ''), trim($row[$headerMap['time']] ?? ''), trim($row[$headerMap['vehicletype']] ?? ''), trim($row[$headerMap['vehicleno']] ?? ''), trim($row[$headerMap['wastetype']] ?? ''), $loggedInUser);
            if ($stmt->execute()) $inserted++;
            $stmt->close();
        }
        $uploadMessage = "✅ $inserted inserted | ⚠️ $skipped skipped.";
    } catch (Exception $e) { $uploadMessage = "❌ Error processing file."; $uploadMessageColor = "red"; }
}

/* ---------- DATE FILTER ---------- */
$date = $_GET['date'] ?? null;
$records = [];
if ($date) {
    $searchDate = date("Y-m-d", strtotime($date));
    $sql = ($loggedInType === 'admin') ? "SELECT * FROM tripdetail WHERE `date` = ?" : "SELECT * FROM tripdetail WHERE `date` = ? AND userID = ?";
    $stmt = $conn->prepare($sql);
    if($loggedInType === 'admin') $stmt->bind_param("s", $searchDate); else $stmt->bind_param("si", $searchDate, $loggedInUser);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) { $records[] = $row; }
    $stmt->close();
}
$formattedDate = $date ? date("d-m-Y", strtotime($date)) : "________";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TCP Performa Generator - ToolNish</title>
    <link rel="icon" href="res/icon.png" type="image/png">
    <!-- SEO Meta --><meta name="google-adsense-account" content="ca-pub-5338649354805856">
    <meta name="keywords" content="TCP Performa Generator, SLWMC Performa, Waste Haulage System, Excel to Performa, SLWMC Tool, Waste Management Pakistan">
    <meta name="description" content="Upload Excel, manage TCP records, and print SLWMC performa easily online.">
    <meta name="author" content="ToolNish">
    <link rel="canonical" href="https://toolnish.com/tcpPerforma">

    <meta property="og:title" content="TCP Performa Generator - ToolNish">
    <meta property="og:description" content="Upload Excel, manage TCP records, and print SLWMC performa easily online.">
    <meta property="og:url" content="https://toolnish.com/tcpPerforma">
    <meta property="og:type" content="website">
    <meta property="og:image" content="https://toolnish.com/res/logo.png">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="TCP Performa Generator - ToolNish">
    <meta name="twitter:description" content="Upload Excel, manage TCP records, and print SLWMC performa easily online.">
    <meta name="twitter:image" content="https://toolnish.com/res/logo.png">

    <meta property="og:title" content="TCP Performa Generator - ToolNish">
    <meta property="og:description" content="Upload Excel, manage TCP records, and print SLWMC performa easily online.">
    <meta property="og:url" content="https://toolnish.com/tcpPerforma">
    <meta property="og:type" content="website">
    <meta property="og:image" content="https://toolnish.com/res/logo.png">

    <link rel="stylesheet" href="res/header-footer.css">
    <script src="res/header-footer.js" defer></script>
    <script type="application/ld+json">
        {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "TCP Performa Generator - ToolNish",
        "url": "https://toolnish.com/tcpPerforma",
        "applicationCategory": "BusinessApplication",
        "description": "Upload Excel, manage TCP records, and print SLWMC performa easily online.",
        "operatingSystem": "Web",
        "creator": {
        "@type": "Organization",
        "name": "SLWMC"
        }
        }
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <style>
        /* ---------- Scrollbar Styling ---------- */
        .form-container::-webkit-scrollbar,
        .preview-container::-webkit-scrollbar { width: 1px; }
        .form-container::-webkit-scrollbar-thumb,
        .preview-container::-webkit-scrollbar-thumb { background-color: #000; border-radius: 3px; }
        .form-container::-webkit-scrollbar-track,
        .preview-container::-webkit-scrollbar-track { background: #f0f0f0; }
        .form-container,
        .preview-container { scrollbar-width: thin; scrollbar-color: #000 #f0f0f0; }
        /* ---------- Layout & Sidebar ---------- */
        .main-content{
           display:grid;
            grid-template-columns:420px 1fr;
            gap:20px;
            padding:15px 0px;
            margin:0;
            align-items:center;
        }
        .form-container {
            position: sticky;
            top: 0px;
            margin-left: 50px;
            overflow: auto;
            max-height:85vh;  /* limit height */
            display: flex;
            flex-direction: column;
            text-align: center;
            background: #ffffff; 
            border-right: 1px solid #ddd; 
            padding: 10px; 
            box-shadow: 4px 0 10px rgba(0,0,0,0.05);
        }
        .preview-container{ max-height:85vh; overflow-y:auto; padding-right:10px; display: flex; flex-direction: column; align-items: center;  }

        /* ---------- Sidebar UI ---------- */
        h2 { font-size: 20px; margin-bottom: 20px; border-bottom: 2px solid #4e73df; padding-bottom: 10px; }
        .control-section { margin: 10px 0px; background: #f8f9fc; padding: 10px; border-radius: 8px; border: 1px solid #e3e6f0; }
        .control-section label { display: block; font-weight: bold; margin-bottom: 8px; font-size: 14px; }
        input[type="date"], input[type="file"] { width: 100%; padding: 10px; margin-bottom: 10px; border: 1px solid #d1d3e2; border-radius: 5px; box-sizing: border-box; }
        
        .btn { width: 100%; padding: 12px; border: none; border-radius: 5px; font-weight: bold; cursor: pointer; transition: 0.3s;  font-size: 14px; }
        .btn-primary { background: #4e73df; color: white; }
        .btn-success { background: #1cc88a; color: white; }
        .btn-info { background: #36b9cc; color: white; }
        .btn-danger { background: #e74a3b; color: white; margin-top: auto; }
        .btn:hover { opacity: 0.9; transform: translateY(-1px); }

        /* ---------- Performa Paper Styling ---------- */
        .page { 
            width: 210mm; height: 297mm; background: #fff; margin: 0px auto 30px; 
            box-shadow: 0 0 20px rgba(0,0,0,0.4); display: flex; flex-direction: column; 
            justify-content: space-between; box-sizing: border-box;
        }
        .form-copy { padding: 12mm 15mm; flex: 1; }
        .separator { border-top: 2px dashed #000; margin: 0; }
        .header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; }
        .logo { width: 70px; }
        .header-text { text-align: center; flex: 1; }
        .header-text h1 { margin: 0; font-size: 22px; text-transform: uppercase; }
        .header-text p { margin: 2px 0; font-size: 11px; }
        .subtitle { font-style: italic; font-weight: bold; font-size: 12px; margin-top: 5px; }
        
        .meta { display: flex; justify-content: space-between; margin: 10px 0; font-size: 13px; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 6px; text-align: center; font-size: 13px; }
        .waste-options { text-align: left; font-size: 11px; }
        .signatures { margin-top: 15px; }
        .signatures div { display: flex; align-items: center; margin-top: 8px; font-size: 13px; }
        .line { flex: 1; border-bottom: 1px solid #000; margin-left: 8px; height: 16px; }

         /* Ad Placeholder */
    .ad-slot {
      width: 100%;
      height: 90px;
      background: #f0f0f0;
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 20px 0;
      color: #555;
      border: 1px dashed #ccc;
    }

    /* FAQ Styling */
    .faq-container {
      width: 100%;
      margin-top: 20px;
    }

    .faq-item {
      width: 100%;
      margin-bottom: 10px;
      border-radius: 8px;
      overflow: hidden;
      background: var(--card);
      box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
    }

    .faq-question {
      width: 100%;
      text-align: left;
      padding: 12px 15px;
      border: none;
      outline: none;
      background: var(--primary);
      color: white;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.3s;
      border-radius: 8px;
    }

    .faq-question:hover {
      background: var(--accent);
    }

    .faq-answer {
      padding: 0 15px;
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.3s ease, padding 0.3s ease;
      background: var(--card);
    }

    .faq-answer.show {
      padding: 12px 15px;
      max-height: 400px;
    }
   
        /* ---------------- SEO ---------------- */
        .seo-section{margin-right: 50px;}
        .seo-section h1{ font-size:2.2rem; color:var(--primary); margin-bottom:15px; text-align:center; }
        .seo-section h2{ font-size:1.5rem; color:var(--accent); margin-top:30px; margin-bottom:10px; border-left:4px solid var(--primary); padding-left:10px; }
        .seo-section p{ font-size:1rem; line-height:1.6; margin-bottom:15px; text-align:justify; background:var(--card); padding:12px 15px; border-radius:10px; box-shadow:0 3px 8px rgba(0,0,0,0.05); transition: transform 0.2s, box-shadow 0.3s; }
        .seo-section p:hover{ transform:translateY(-2px); box-shadow:0 6px 15px rgba(0,0,0,0.08); }
        .seo-section ul{ list-style: inside disc; margin-left:0; padding-left:15px; margin-bottom:20px; background:var(--card); padding:12px 15px; border-radius:10px; box-shadow:0 3px 8px rgba(0,0,0,0.05); transition: transform 0.2s, box-shadow 0.3s; }
        .seo-section ul li{ padding:5px 0; font-weight:500; }
        .seo-section a{ color:var(--primary); text-decoration:none; font-weight:600; transition: color 0.3s; }
        .seo-section a:hover{ color:var(--accent); text-decoration:underline; }


        @media print {
            .form-container, header, footer, .seo-section { display: none !important; }
            .main-content { display: block; }
            .preview-container { padding: 0; background: none; overflow: visible; }
            .page { box-shadow: none; margin: 0; page-break-after: always; width: 100%; min-height: auto; display: block; }
        }
        /* ---------- Mobile ---------- */
        @media (max-width: 1000px) {
            .main-content {
                grid-template-columns: 1fr;  /* stack vertically */
                justify-items: center;        /* center children horizontally */
                padding: 15px 0;             /* optional padding */
            }
            .form-container {
                position: relative;           /* remove sticky on mobile */
                top: auto;
                margin: auto;        /* remove sticky on mobile */
                width: 95%;                   /* center preview */
                max-width: 420px; 
            }
            .preview-container {
                width: 95%;                   /* center preview */
                max-width: 1000px;            /* optional max width */
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); /* flexible columns */
            }
            .seo-section{margin-right: 0px;}
        }
    </style>
</head>
<body>
<div class="main-content">
    <div class="form-container">
        <h1>TCP Performa</h1>
        
        <div class="control-section">
            <form method="get">
                <label>Filter by Date</label>
                <input type="date" name="date" value="<?= htmlspecialchars($date ?? '') ?>">
                <button type="submit" class="btn btn-primary">Load Performa</button>
                <button style="margin-top: 10px;" class="btn btn-info" onclick="window.print()">Print All Records</button>
            </form>
        </div>


        <div class="control-section">
            <form method="post" enctype="multipart/form-data">
                <label>Import Trip Data</label>
                <input type="file" name="excelFile" accept=".xlsx,.xls,.csv" required>
                <button type="submit" name="uploadExcel" class="btn btn-success">Upload Excel</button>
            </form>
            <?php if($uploadMessage): ?>
                <div style="font-size: 12px; color: <?= $uploadMessageColor ?>; margin-top: 10px; font-weight: bold;"><?= $uploadMessage ?></div>
            <?php endif; ?>
        </div>

        <form method="post">
            <p style="font-size: 16px; text-align: center;  ">User: <strong><?= htmlspecialchars($_SESSION['username']) ?></strong></p>
            <button name="logout" class="btn btn-danger">Logout</button>
        </form>
    </div>

    <div class="preview-container">
        <?php if (!empty($records)): ?>
            <?php foreach ($records as $record): ?>
                <div class="page">
                    <!-- COPY FOR CONTRACTOR -->
                    <div class="form-copy">
                        <div class="header">
                            <img src="data/iconLeft.png" class="logo">
                            <div class="header-text">
                                <h1 >Sahiwal Waste Management Company</h1>
                                <p style="box-shadow: none; text-align: center;">Top Floor Sattar Corporate Centre, Opposite DPO Office, Sahiwal.</p>
                                <p style="box-shadow: none; text-align: center;" class="subtitle">
                                    (Haulage from Transfer Station / Collection Point to Landfill Dump Site)<br>
                                    <strong>(Copy for Control Room)</strong>
                                </p>
                            </div>
                            <img src="data/iconRight.png" class="logo">
                        </div>
                        <div class="meta">
                            <div>Book No: <?= htmlspecialchars($record['bookNo']) ?></div>
                            <div>Serial No: <?= htmlspecialchars($record['serialNo']) ?></div>
                        </div>
                        <div class="meta">
                            <div></div>
                            <div>Date: <?= $formattedDate ?></div>
                        </div>
                        <table>
                        <tr>
                            <th>Tehsil</th>
                            <th>Name of Transfer Station / Collection Point</th>
                            <th>Time of Activity</th>
                            <th>Vehicle Type</th>
                            <th>Vehicle No.</th>
                            <th>Waste Type</th>
                        </tr>
                        <tr>
                            <td><?= htmlspecialchars($record['tehsil']) ?></td>
                            <td><?= htmlspecialchars($record['pointName']) ?></td>
                            <td><?= htmlspecialchars($record['time']) ?></td>
                            <td><?= htmlspecialchars($record['vehicleType']) ?></td>
                            <td><?= htmlspecialchars($record['vehicleNo']) ?></td>
                            <td class="waste-options">
                                <label><input type="checkbox" <?= stripos($record['wasteType'],'municipal')!==false?'checked':'' ?>> Municipal Waste</label><br>
                                <label><input type="checkbox" <?= stripos($record['wasteType'],'bulk')!==false?'checked':'' ?>> Bulk Waste</label>
                            </td>
                        </tr>
                        </table>
                        <br>
                        <div class="remarks">
                            <span>Remarks (if any):</span><span class="line"></span>
                        </div>
                        <div class="signatures">
                            <div>Name & Signature of Supervisor (TS/TCP):<span class="line"></span></div>
                            <div>Name/Sign of Contractor:<span class="line"></span></div>
                        </div>
                    </div>

                    <div class="separator"></div>

                    <!-- COPY FOR MANAGER -->
                    <div class="form-copy">
                        <div class="header">
                            <img src="data/iconLeft.png" class="logo">
                            <div class="header-text">
                                <h1 >Sahiwal Waste Management Company</h1>
                                <p style="box-shadow: none; text-align: center;">Top Floor Sattar Corporate Centre, Opposite DPO Office, Sahiwal.</p>
                                <p style="box-shadow: none; text-align: center;" class="subtitle">
                                    (Haulage from Transfer Station / Collection Point to Landfill Dump Site)<br>
                                    <strong>(Copy for Manager TS/TCP)</strong>
                                </p>
                            </div>
                            <img src="data/iconRight.png" class="logo">
                        </div>
                        <div class="meta">
                            <div>Book No: <?= htmlspecialchars($record['bookNo']) ?></div>
                            <div>Serial No: <?= htmlspecialchars($record['serialNo']) ?></div>
                        </div>
                        <div class="meta">
                            <div></div>
                            <div>Date: <?= $formattedDate ?></div>
                        </div>
                        <table>
                            <tr>
                                <th>Tehsil</th>
                                <th>Name of Transfer Station / Collection Point</th>
                                <th>Time of Activity</th>
                                <th>Vehicle Type</th>
                                <th>Vehicle No.</th>
                                <th>Waste Type</th>
                            </tr>
                            <tr>
                                <td><?= htmlspecialchars($record['tehsil']) ?></td>
                                <td><?= htmlspecialchars($record['pointName']) ?></td>
                                <td><?= htmlspecialchars($record['time']) ?></td>
                                <td><?= htmlspecialchars($record['vehicleType']) ?></td>
                                <td><?= htmlspecialchars($record['vehicleNo']) ?></td>
                                <td class="waste-options">
                                    <label><input type="checkbox" <?= stripos($record['wasteType'],'municipal')!==false?'checked':'' ?>> Municipal Waste</label><br>
                                    <label><input type="checkbox" <?= stripos($record['wasteType'],'bulk')!==false?'checked':'' ?>> Bulk Waste</label>
                                </td>
                            </tr>
                        </table>
                        <br>
                        <div class="remarks">
                            <span>Remarks (if any):</span><span class="line"></span>
                        </div>
                        <div class="signatures">
                            <div>Name & Signature of Supervisor (TS/TCP):<span class="line"></span></div>
                            <div>Name/Sign of Contractor:<span class="line"></span></div>
                        </div>
                    </div>

                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align: center; margin-top: 100px;">
                <h2>No data loaded</h2>
                <p>Use the left panel to select a date or upload an excel sheet.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="seo-section" style="padding: 20px; max-width:900px; margin:auto; text-align:start;">

<h1>TCP Performa Generator Online - SLWMC Tool</h1>
<p>
The TCP Performa Generator by ToolNish is a powerful online system designed for waste management operations. It allows users to upload Excel data, manage trip records, and generate professional TCP performa instantly. This tool is especially useful for organizations like SLWMC (Sahiwal Waste Management Company) to streamline daily reporting and documentation processes.
</p>

<p>
Instead of manually preparing performa sheets, this system automates everything. From Excel upload to printable reports, the entire workflow is optimized for speed, accuracy, and efficiency. It reduces human error and ensures standardized reporting across all departments.
</p>

    <div class="ad-slot">Ad Slot</div>

<!-- HOW TO USE -->
<h2>How to Use TCP Performa Generator</h2>
<p>
Using this tool is simple and user-friendly. First, log in using your credentials. Then upload your Excel file containing trip details such as serial number, date, vehicle information, and waste type. The system automatically processes the file and stores valid records in the database.
</p>

<ul>
<li>Login with your assigned username and password</li>
<li>Upload Excel file with trip data</li>
<li>System validates and inserts records</li>
<li>Select date to filter records</li>
<li>View auto-generated performa</li>
<li>Print performa for official use</li>
</ul>

<!-- FEATURES -->
<h2>Key Features of TCP Performa System</h2>
<ul>
<li>Excel import with automatic column detection</li>
<li>Duplicate record prevention system</li>
<li>Role-based access control (Admin & User)</li>
<li>Date-wise filtering of records</li>
<li>Auto-generated printable performa layout</li>
<li>Fast performance and secure database handling</li>
<li>User-specific data filtering for better control</li>
</ul>

<!-- BENEFITS -->
<h2>Benefits of Using This System</h2>
<p>
Manual data entry and reporting can be time-consuming and error-prone. This system eliminates repetitive tasks by automating data processing and performa generation. It improves operational efficiency and ensures that all records are properly formatted and easy to access.
</p>

<p>
With real-time data handling and instant printing capabilities, users can generate official documents within seconds. This is especially important for field operations where time and accuracy are critical.
</p>
    <div class="ad-slot">Ad Slot</div>

<!-- USE CASE -->
<h2>Use Cases of TCP Performa Generator</h2>
<ul>
<li>Waste management companies (SLWMC)</li>
<li>Field supervisors tracking vehicle trips</li>
<li>Contractors managing waste collection</li>
<li>Government reporting and documentation</li>
<li>Daily operational record keeping</li>
</ul>

<!-- WHY IMPORTANT -->
<h2>Why This Tool is Important for Waste Management</h2>
<p>
Efficient waste management requires accurate tracking of vehicle movements and waste collection activities. The TCP Performa Generator ensures that all trip data is recorded systematically and can be easily retrieved for reporting and auditing purposes.
</p>

<p>
By digitizing the process, organizations can reduce paperwork, improve transparency, and maintain a reliable database of operations. This leads to better decision-making and improved service delivery.
</p>

<!-- FAQ -->
<h2>Frequently Asked Questions (FAQ)</h2>

<div class="faq-item">
<button class="faq-question">Q: Is this TCP Performa Generator free?</button>
<div class="faq-answer">Yes, this tool is free to use for authorized users.</div>
</div>

<div class="faq-item">
<button class="faq-question">Q: What file formats are supported?</button>
<div class="faq-answer">You can upload Excel files including .xlsx, .xls, and .csv formats.</div>
</div>

<div class="faq-item">
<button class="faq-question">Q: Can I upload duplicate data?</button>
<div class="faq-answer">No, the system automatically detects and skips duplicate records.</div>
</div>

<div class="faq-item">
<button class="faq-question">Q: Is my data secure?</button>
<div class="faq-answer">Yes, all data is securely stored in the database and access is restricted based on user roles.</div>
</div>

<div class="faq-item">
<button class="faq-question">Q: Can normal users see all records?</button>
<div class="faq-answer">No, users can only view their own data. Admins have full access.</div>
</div>

<div class="faq-item">
<button class="faq-question">Q: Can I print performa directly?</button>
<div class="faq-answer">Yes, you can print all generated performa using the built-in print option.</div>
</div>

<div class="faq-item">
<button class="faq-question">Q: Does this tool require installation?</button>
<div class="faq-answer">No, it works completely online in your browser.</div>
</div>

<div class="faq-item">
<button class="faq-question">Q: Who can use this tool?</button>
<div class="faq-answer">This tool is designed for SLWMC staff, contractors, supervisors, and administrative users.</div>
</div>

<!-- RELATED TOOLS -->
<h2>Related Tools</h2>
<p>
Explore more tools on ToolNish to improve your workflow:
<a href="slwmcPdf.html">SLWMC Slides PDF Generator</a>, 
<a href="gpsStamp.html">GPS Photo Stamp Tool</a>, 
<a href="pdfMerge.html">PDF Merge Tool</a>, 
<a href="unitConverter.html">Unit Converter</a>.
</p>
    <div class="ad-slot">Ad Slot</div>


</div>


<script>
const faqButtons = document.querySelectorAll(".faq-question");
faqButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    const answer = btn.nextElementSibling;
    answer.classList.toggle("show");
  });
});
</script>

</body>
</html>