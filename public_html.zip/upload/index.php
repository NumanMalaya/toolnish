<?php

session_start();

error_reporting(E_ALL & ~E_DEPRECATED);
ini_set('display_errors', 0);


/* =========================================================
   DB CONNECTION
   ========================================================= */

$host = "127.0.0.1:3306";
$user = "u850285897_ToolNish";
$pass = "Numan@22244";
$db   = "u850285897_ToolNish";

$conn = new mysqli(
    $host,
    $user,
    $pass,
    $db
);

if ($conn->connect_error) {

    die(
        "DB Connection Failed: " .
        $conn->connect_error
    );

}


/* =========================================================
   HANDLE LOGIN
   ========================================================= */

$loginError = "";

if (isset($_POST['login'])) {

    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare(
        "SELECT userID, password, type
         FROM user
         WHERE username = ?"
    );

    $stmt->bind_param(
        "s",
        $username
    );

    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows === 1) {

        $row = $result->fetch_assoc();

        /*
           Keeping your existing password
           comparison system.
        */

        if ($password === $row['password']) {

            $_SESSION['userID'] =
                $row['userID'];

            $_SESSION['username'] =
                $username;

            $_SESSION['type'] =
                $row['type'];

        } else {

            $loginError =
                "Incorrect password!";

        }

    } else {

        $loginError =
            "Username not found!";

    }

    $stmt->close();

}


/* =========================================================
   HANDLE LOGOUT
   ========================================================= */

if (isset($_POST['logout'])) {

    session_destroy();

    header(
        "Location: " .
        $_SERVER['PHP_SELF']
    );

    exit();

}


/* =========================================================
   SHOW LOGIN IF NOT LOGGED IN
   ========================================================= */

if (!isset($_SESSION['userID'])):

?>

<!DOCTYPE html>

<html>

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Login - ToolNish
    </title>


    <style>

        * {
            box-sizing: border-box;
        }


        body {

            font-family:
                Arial,
                sans-serif;

            background:
                #f0f2f5;

            display:
                flex;

            justify-content:
                center;

            align-items:
                center;

            height:
                100vh;

            margin:
                0;

        }


        .login-form {

            background:
                #ffffff;

            padding:
                30px;

            border-radius:
                14px;

            box-shadow:
                0 10px 30px
                rgba(0,0,0,0.10);

            width:
                320px;

        }


        .login-form h2 {

            text-align:
                center;

            margin-top:
                0;

            margin-bottom:
                25px;

        }


        .login-label {

            display:
                block;

            margin-bottom:
                6px;

            font-size:
                14px;

        }


        .login-input {

            width:
                100%;

            padding:
                11px;

            margin-bottom:
                16px;

            border:
                1px solid #ddd;

            border-radius:
                7px;

            outline:
                none;

        }


        .login-input:focus {

            border-color:
                #4e73df;

        }


        .login-button {

            width:
                100%;

            padding:
                12px;

            background:
                #007bff;

            color:
                #fff;

            border:
                none;

            border-radius:
                7px;

            font-weight:
                bold;

            cursor:
                pointer;

        }


        .login-button:hover {

            background:
                #0069d9;

        }


        .login-error {

            color:
                #dc2626;

            font-size:
                14px;

            text-align:
                center;

        }

    </style>

</head>


<body>


<form
    method="post"
    class="login-form"
>


    <h2>
        File Manager Login
    </h2>


    <?php if ($loginError): ?>

        <p class="login-error">

            <?= htmlspecialchars(
                $loginError
            ) ?>

        </p>

    <?php endif; ?>


    <label class="login-label">

        Username

    </label>


    <input
        type="text"
        name="username"
        required
        class="login-input"
        autocomplete="username"
    >


    <label class="login-label">

        Password

    </label>


    <input
        type="password"
        name="password"
        required
        class="login-input"
        autocomplete="current-password"
    >


    <button
        type="submit"
        name="login"
        class="login-button"
    >

        Sign In

    </button>


</form>


</body>

</html>

<?php

exit();

endif;


/* =========================================================
   LOGGED-IN USER
   ========================================================= */

$loggedInUser =
    $_SESSION['userID'];

$loggedInType =
    $_SESSION['type'];

$loggedInName =
    $_SESSION['username'];


/* =========================================================
   FILE UPLOAD SETTINGS
   ========================================================= */

$uploadDir =
    __DIR__ . "/uploads/";

$uploadWebPath =
    "uploads/";


/*
   Maximum upload size:

   500 MB
*/

$maxFileSize =
    500 * 1024 * 1024;


/* =========================================================
   CREATE UPLOAD DIRECTORY
   ========================================================= */

if (!is_dir($uploadDir)) {

    mkdir(
        $uploadDir,
        0755,
        true
    );

}


/* =========================================================
   AJAX UPLOAD RESPONSE
   ========================================================= */

$isAjaxUpload =
    isset($_POST['uploadFile']) &&
    isset($_FILES['file']);


/* =========================================================
   HANDLE FILE UPLOAD
   ========================================================= */

if ($isAjaxUpload) {

    /*
       Always return JSON for AJAX.
    */

    header(
        "Content-Type: application/json; charset=UTF-8"
    );


    /*
       Make sure file exists.
    */

    if (
        !isset($_FILES['file']) ||
        !is_array($_FILES['file'])
    ) {

        echo json_encode([
            "success" => false,
            "message" =>
                "No file was received by the server."
        ]);

        exit();

    }


    $uploadError =
        $_FILES['file']['error'];


    /*
       Handle PHP upload errors.
    */

    if (
        $uploadError !==
        UPLOAD_ERR_OK
    ) {

        $errorMessages = [

            UPLOAD_ERR_INI_SIZE =>
                "The file exceeds the server upload limit.",

            UPLOAD_ERR_FORM_SIZE =>
                "The file exceeds the form upload limit.",

            UPLOAD_ERR_PARTIAL =>
                "The file was only partially uploaded.",

            UPLOAD_ERR_NO_FILE =>
                "No file was uploaded.",

            UPLOAD_ERR_NO_TMP_DIR =>
                "Server temporary folder is missing.",

            UPLOAD_ERR_CANT_WRITE =>
                "Server could not write the uploaded file.",

            UPLOAD_ERR_EXTENSION =>
                "A server extension stopped the upload."

        ];


        $message =
            $errorMessages[$uploadError]
            ??
            "Unknown upload error.";


        echo json_encode([
            "success" => false,
            "message" => $message,
            "error_code" => $uploadError
        ]);

        exit();

    }


    /*
       Get uploaded file information.
    */

    $originalName =
        $_FILES['file']['name'];

    $tmpName =
        $_FILES['file']['tmp_name'];

    $fileSize =
        (int)$_FILES['file']['size'];


    /*
       Empty file check.
    */

    if ($fileSize <= 0) {

        echo json_encode([
            "success" => false,
            "message" =>
                "The selected file is empty."
        ]);

        exit();

    }


    /*
       500 MB validation.
    */

    if (
        $fileSize >
        $maxFileSize
    ) {

        echo json_encode([
            "success" => false,
            "message" =>
                "File is too large. Maximum size is 500 MB."
        ]);

        exit();

    }


    /*
       Clean original filename.

       We store the original name in DB,
       but NEVER use it as the physical
       filename.
    */

    $originalName =
        basename($originalName);


    /*
       Get extension.

       We are NOT restricting extensions.

       Therefore files such as:

       .cs
       .php
       .js
       .html
       .css
       .zip
       .rar
       .exe
       .txt
       .pdf
       etc.

       can be uploaded.
    */

    $extension =
        pathinfo(
            $originalName,
            PATHINFO_EXTENSION
        );

    $extension =
        strtolower($extension);


    /*
       Generate random secure filename.
    */

    try {

        $storedName =
            bin2hex(
                random_bytes(24)
            );

    } catch (Exception $e) {

        echo json_encode([
            "success" => false,
            "message" =>
                "Unable to generate a secure filename."
        ]);

        exit();

    }


    /*
       Add original extension.
    */

    if ($extension !== '') {

        $storedName .=
            "." . $extension;

    }


    /*
       Final physical file path.
    */

    $filePath =
        $uploadDir .
        $storedName;


    /*
       Detect MIME type.

       This is only stored as metadata.
       It does NOT restrict file types.
    */

    $fileType = "";


    if (
        function_exists(
            'finfo_open'
        )
    ) {

        $finfo =
            finfo_open(
                FILEINFO_MIME_TYPE
            );


        if ($finfo) {

            $fileType =
                finfo_file(
                    $finfo,
                    $tmpName
                );


            finfo_close(
                $finfo
            );

        }

    }


    /*
       If MIME detection fails,
       use uploaded type.
    */

    if (
        !$fileType &&
        isset($_FILES['file']['type'])
    ) {

        $fileType =
            $_FILES['file']['type'];

    }


    /*
       Move file from PHP temporary
       directory to uploads folder.
    */

    if (
        !move_uploaded_file(
            $tmpName,
            $filePath
        )
    ) {

        echo json_encode([
            "success" => false,
            "message" =>
                "Unable to save the uploaded file. Check the uploads folder permissions."
        ]);

        exit();

    }


    /*
       Database path.
    */

    $databasePath =
        $uploadWebPath .
        $storedName;


    /*
       Insert database record.
    */

    $stmt =
        $conn->prepare(
            "INSERT INTO uploaded
            (
                original_name,
                stored_name,
                file_path,
                file_type,
                file_size
            )
            VALUES (?, ?, ?, ?, ?)"
        );


    if (!$stmt) {

        /*
           Delete physical file
           if DB statement fails.
        */

        if (
            file_exists(
                $filePath
            )
        ) {

            unlink(
                $filePath
            );

        }


        echo json_encode([
            "success" => false,
            "message" =>
                "Database preparation failed."
        ]);

        exit();

    }


    $stmt->bind_param(
        "ssssi",
        $originalName,
        $storedName,
        $databasePath,
        $fileType,
        $fileSize
    );


    if (
        $stmt->execute()
    ) {

        $stmt->close();


        echo json_encode([

            "success" => true,

            "message" =>
                "File uploaded successfully.",

            "file_name" =>
                $originalName,

            "file_size" =>
                $fileSize

        ]);

        exit();

    }


    /*
       Database insertion failed.
    */

    $stmt->close();


    /*
       Remove uploaded file
       because DB record failed.
    */

    if (
        file_exists(
            $filePath
        )
    ) {

        unlink(
            $filePath
        );

    }


    echo json_encode([
        "success" => false,
        "message" =>
            "Database error while saving file."
    ]);

    exit();

}


/* =========================================================
   HANDLE DELETE
   ========================================================= */

if (isset($_POST['deleteFile'])) {

    $uploadedId =
        intval(
            $_POST['uploadedId'] ?? 0
        );


    if ($uploadedId > 0) {

        /*
           Get stored filename.
        */

        $stmt =
            $conn->prepare(
                "SELECT stored_name
                 FROM uploaded
                 WHERE uploadedId = ?"
            );


        $stmt->bind_param(
            "i",
            $uploadedId
        );


        $stmt->execute();


        $result =
            $stmt->get_result();


        if (
            $result->num_rows === 1
        ) {

            $file =
                $result->fetch_assoc();


            $physicalPath =
                $uploadDir .
                $file['stored_name'];


            /*
               Delete physical file.
            */

            if (
                file_exists(
                    $physicalPath
                )
            ) {

                unlink(
                    $physicalPath
                );

            }


            /*
               Delete DB record.
            */

            $deleteStmt =
                $conn->prepare(
                    "DELETE FROM uploaded
                     WHERE uploadedId = ?"
                );


            $deleteStmt->bind_param(
                "i",
                $uploadedId
            );


            $deleteStmt->execute();


            $deleteStmt->close();

        }


        $stmt->close();

    }


    /*
       Refresh page.
    */

    header(
        "Location: " .
        $_SERVER['PHP_SELF']
    );

    exit();

}


/* =========================================================
   GET ALL UPLOADED FILES
   ========================================================= */

$uploadedFiles = [];


$result =
    $conn->query(
        "SELECT *
         FROM uploaded
         ORDER BY uploadedId DESC"
    );


if ($result) {

    while (
        $row =
        $result->fetch_assoc()
    ) {

        $uploadedFiles[] =
            $row;

    }

}


/* =========================================================
   FORMAT FILE SIZE
   ========================================================= */

function formatFileSize(
    $bytes
) {

    if (
        $bytes <= 0
    ) {

        return "0 B";

    }


    $units = [
        "B",
        "KB",
        "MB",
        "GB"
    ];


    $power =
        floor(
            log(
                $bytes,
                1024
            )
        );


    $power =
        min(
            $power,
            count($units) - 1
        );


    return round(
        $bytes /
        pow(
            1024,
            $power
        ),
        2
    )
    . " "
    . $units[$power];

}

?>


<!DOCTYPE html>

<html lang="en">


<head>

    <meta charset="UTF-8">


    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >


    <title>
        File Upload Manager - ToolNish
    </title>


    <link
        rel="icon"
        href="res/icon.png"
        type="image/png"
    >


    <link
        rel="stylesheet"
        href="res/header-footer.css"
    >


    <script
        src="res/header-footer.js"
        defer
    ></script>


    <style>

        /* =====================================================
           GLOBAL
           ===================================================== */

        * {
            box-sizing: border-box;
        }


        body {

            margin:
                0;

            font-family:
                Inter,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                Arial,
                sans-serif;

            background:
                linear-gradient(
                    135deg,
                    #f5f7fb 0%,
                    #eef2f7 100%
                );

            color:
                #1f2937;

        }


        /* =====================================================
           MAIN CONTAINER
           ===================================================== */

        .container {

            width:
                95%;

            max-width:
                1100px;

            margin:
                40px auto;

        }


        /* =====================================================
           TOP BAR
           ===================================================== */

        .top-bar {

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.95
                );

            padding:
                20px 25px;

            border-radius:
                16px;

            box-shadow:
                0 8px 30px
                rgba(
                    0,
                    0,
                    0,
                    0.06
                );

            display:
                flex;

            justify-content:
                space-between;

            align-items:
                center;

            margin-bottom:
                25px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.7
                );

        }


        .top-bar h1 {

            margin:
                0;

            font-size:
                24px;

        }


        .user-info {

            margin-top:
                5px;

            font-size:
                14px;

            color:
                #6b7280;

        }


        .logout-btn {

            margin-left:
                15px;

            background:
                #ef4444;

            color:
                white;

            border:
                none;

            padding:
                10px 18px;

            border-radius:
                8px;

            cursor:
                pointer;

            font-weight:
                600;

            transition:
                0.2s;

        }


        .logout-btn:hover {

            background:
                #dc2626;

            transform:
                translateY(-1px);

        }


        /* =====================================================
           UPLOAD CARD
           ===================================================== */

        .upload-card {

            background:
                white;

            padding:
                30px;

            border-radius:
                16px;

            box-shadow:
                0 8px 30px
                rgba(
                    0,
                    0,
                    0,
                    0.06
                );

            margin-bottom:
                25px;

        }


        .upload-card h2 {

            margin-top:
                0;

            margin-bottom:
                20px;

        }


        /* =====================================================
           FILE INPUT
           ===================================================== */

        .file-input {

            width:
                100%;

            padding:
                15px;

            border:
                2px dashed
                #cbd5e1;

            border-radius:
                10px;

            background:
                #f8fafc;

            cursor:
                pointer;

            margin-bottom:
                15px;

            transition:
                0.2s;

        }


        .file-input:hover {

            border-color:
                #4e73df;

            background:
                #f8faff;

        }


        /* =====================================================
           UPLOAD BUTTON
           ===================================================== */

        .upload-btn {

            width:
                100%;

            padding:
                14px;

            background:
                linear-gradient(
                    135deg,
                    #10b981,
                    #059669
                );

            color:
                white;

            border:
                none;

            border-radius:
                9px;

            font-weight:
                700;

            font-size:
                15px;

            cursor:
                pointer;

            transition:
                0.2s;

        }


        .upload-btn:hover {

            transform:
                translateY(-1px);

            box-shadow:
                0 5px 15px
                rgba(
                    16,
                    185,
                    129,
                    0.25
                );

        }


        .upload-btn:disabled {

            opacity:
                0.7;

            cursor:
                not-allowed;

            transform:
                none;

        }


        /* =====================================================
           MESSAGE
           ===================================================== */

        .message {

            margin-top:
                15px;

            padding:
                10px;

            border-radius:
                7px;

            text-align:
                center;

            font-weight:
                bold;

            font-size:
                14px;

        }


        /* =====================================================
           FILES CARD
           ===================================================== */

        .files-card {

            background:
                white;

            padding:
                25px;

            border-radius:
                16px;

            box-shadow:
                0 8px 30px
                rgba(
                    0,
                    0,
                    0,
                    0.06
                );

            overflow-x:
                auto;

        }


        .files-card h2 {

            margin-top:
                0;

        }


        table {

            width:
                100%;

            border-collapse:
                collapse;

            margin-top:
                15px;

        }


        th,
        td {

            padding:
                13px;

            border-bottom:
                1px solid
                #e5e7eb;

            text-align:
                left;

            font-size:
                14px;

        }


        th {

            background:
                #f8fafc;

            font-weight:
                700;

        }


        tr:hover {

            background:
                #fafafa;

        }


        /* =====================================================
           BUTTONS
           ===================================================== */

        .download-btn {

            display:
                inline-block;

            padding:
                7px 12px;

            background:
                #06b6d4;

            color:
                white;

            text-decoration:
                none;

            border-radius:
                6px;

            font-size:
                12px;

            font-weight:
                bold;

            transition:
                0.2s;

        }


        .download-btn:hover {

            background:
                #0891b2;

        }


        .delete-btn {

            padding:
                7px 12px;

            background:
                #ef4444;

            color:
                white;

            border:
                none;

            border-radius:
                6px;

            font-size:
                12px;

            font-weight:
                bold;

            cursor:
                pointer;

        }


        .delete-btn:hover {

            background:
                #dc2626;

        }


        /* =====================================================
           FILE INFO
           ===================================================== */

        .file-name {

            font-weight:
                700;

            word-break:
                break-word;

        }


        .file-type {

            color:
                #666;

            font-size:
                12px;

        }


        .empty {

            text-align:
                center;

            padding:
                50px;

            color:
                #777;

        }


        /* =====================================================
           MODERN UPLOAD OVERLAY
           ===================================================== */

        .upload-overlay {

            position:
                fixed;

            inset:
                0;

            display:
                none;

            justify-content:
                center;

            align-items:
                center;

            background:
                rgba(
                    15,
                    23,
                    42,
                    0.72
                );

            backdrop-filter:
                blur(12px);

            -webkit-backdrop-filter:
                blur(12px);

            z-index:
                999999;

            padding:
                20px;

            animation:
                overlayFade
                0.2s
                ease;

        }


        @keyframes overlayFade {

            from {
                opacity:
                    0;
            }

            to {
                opacity:
                    1;
            }

        }


        /* =====================================================
           MODAL
           ===================================================== */

        .upload-loader {

            width:
                100%;

            max-width:
                480px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.98
                );

            border-radius:
                24px;

            padding:
                35px 32px 30px;

            text-align:
                center;

            box-shadow:
                0 25px 80px
                rgba(
                    0,
                    0,
                    0,
                    0.3
                );

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.8
                );

            animation:
                modalEnter
                0.35s
                cubic-bezier(
                    0.16,
                    1,
                    0.3,
                    1
                );

        }


        @keyframes modalEnter {

            from {

                opacity:
                    0;

                transform:
                    translateY(20px)
                    scale(0.96);

            }

            to {

                opacity:
                    1;

                transform:
                    translateY(0)
                    scale(1);

            }

        }


        /* =====================================================
           UPLOAD ICON
           ===================================================== */

        .upload-icon {

            width:
                72px;

            height:
                72px;

            margin:
                0 auto 20px;

            border-radius:
                50%;

            background:
                linear-gradient(
                    135deg,
                    #4e73df,
                    #6366f1
                );

            display:
                flex;

            align-items:
                center;

            justify-content:
                center;

            box-shadow:
                0 10px 30px
                rgba(
                    78,
                    115,
                    223,
                    0.3
                );

            animation:
                iconPulse
                2s
                ease-in-out
                infinite;

        }


        .upload-icon svg {

            width:
                34px;

            height:
                34px;

            fill:
                white;

        }


        @keyframes iconPulse {

            0%,
            100% {

                transform:
                    scale(1);

            }

            50% {

                transform:
                    scale(1.06);

            }

        }


        /* =====================================================
           MODAL TEXT
           ===================================================== */

        .upload-loader h2 {

            margin:
                0 0 8px;

            font-size:
                22px;

            color:
                #111827;

        }


        .upload-status {

            margin:
                0 0 20px;

            color:
                #6b7280;

            font-size:
                14px;

            line-height:
                1.5;

            word-break:
                break-word;

        }


        /* =====================================================
           PROGRESS BAR
           ===================================================== */

        .progress-container {

            width:
                100%;

            height:
                12px;

            background:
                #e5e7eb;

            border-radius:
                20px;

            overflow:
                hidden;

            margin-top:
                15px;

        }


        .progress-bar {

            width:
                0%;

            height:
                100%;

            background:
                linear-gradient(
                    90deg,
                    #4e73df,
                    #6366f1,
                    #8b5cf6
                );

            border-radius:
                20px;

            transition:
                width
                0.15s
                ease;

            position:
                relative;

            overflow:
                hidden;

        }


        .progress-bar::after {

            content:
                "";

            position:
                absolute;

            top:
                0;

            left:
                -100px;

            width:
                100px;

            height:
                100%;

            background:
                linear-gradient(
                    90deg,
                    transparent,
                    rgba(
                        255,
                        255,
                        255,
                        0.45
                    ),
                    transparent
                );

            animation:
                progressShine
                1.2s
                linear
                infinite;

        }


        @keyframes progressShine {

            from {
                left:
                    -100px;
            }

            to {
                left:
                    100%;
            }

        }


        /* =====================================================
           PROGRESS INFO
           ===================================================== */

        .progress-info {

            display:
                flex;

            justify-content:
                space-between;

            align-items:
                center;

            margin-top:
                12px;

            font-size:
                13px;

            gap:
                15px;

        }


        .progress-left {

            text-align:
                left;

            flex:
                1;

        }


        .progress-label {

            color:
                #64748b;

            font-weight:
                600;

        }


        .progress-details {

            margin-top:
                5px;

            color:
                #94a3b8;

            font-size:
                12px;

        }


        .progress-percent {

            font-size:
                21px;

            font-weight:
                800;

            color:
                #4e73df;

            min-width:
                65px;

            text-align:
                right;

        }


        /* =====================================================
           SPEED / TIME
           ===================================================== */

        .upload-stats {

            display:
                grid;

            grid-template-columns:
                1fr 1fr;

            gap:
                10px;

            margin-top:
                15px;

        }


        .stat-box {

            background:
                #f8fafc;

            border:
                1px solid
                #e5e7eb;

            border-radius:
                10px;

            padding:
                10px;

        }


        .stat-title {

            font-size:
                11px;

            color:
                #94a3b8;

            margin-bottom:
                3px;

            text-transform:
                uppercase;

            letter-spacing:
                0.4px;

        }


        .stat-value {

            font-size:
                14px;

            font-weight:
                700;

            color:
                #334155;

        }


        /* =====================================================
           SELECTED FILE
           ===================================================== */

        .selected-file {

            margin-top:
                18px;

            padding:
                11px 13px;

            background:
                #f8fafc;

            border:
                1px solid
                #e5e7eb;

            border-radius:
                9px;

            font-size:
                12px;

            color:
                #64748b;

            white-space:
                nowrap;

            overflow:
                hidden;

            text-overflow:
                ellipsis;

        }


        /* =====================================================
           PROCESSING SPINNER
           ===================================================== */

        .processing-spinner {

            width:
                16px;

            height:
                16px;

            display:
                inline-block;

            vertical-align:
                middle;

            margin-right:
                6px;

            border:
                2px solid
                #dbeafe;

            border-top-color:
                #4e73df;

            border-radius:
                50%;

            animation:
                smallSpin
                0.8s
                linear
                infinite;

        }


        @keyframes smallSpin {

            to {

                transform:
                    rotate(360deg);

            }

        }


        /* =====================================================
           SUCCESS ICON
           ===================================================== */

        .success-icon {

            background:
                linear-gradient(
                    135deg,
                    #10b981,
                    #059669
                );

            box-shadow:
                0 10px 30px
                rgba(
                    16,
                    185,
                    129,
                    0.3
                );

        }


        .success-icon svg {

            fill:
                white;

        }


        /* =====================================================
           ERROR ICON
           ===================================================== */

        .error-icon {

            background:
                linear-gradient(
                    135deg,
                    #ef4444,
                    #dc2626
                );

            box-shadow:
                0 10px 30px
                rgba(
                    239,
                    68,
                    68,
                    0.3
                );

        }


        /* =====================================================
           MOBILE
           ===================================================== */

        @media (
            max-width: 700px
        ) {

            .container {

                width:
                    95%;

                margin:
                    20px auto;

            }


            .top-bar {

                flex-direction:
                    column;

                align-items:
                    flex-start;

                gap:
                    15px;

            }


            .logout-btn {

                margin-left:
                    0;

            }


            .upload-card,
            .files-card {

                padding:
                    20px;

            }


            th,
            td {

                white-space:
                    nowrap;

            }


            .upload-loader {

                padding:
                    30px 22px 25px;

                border-radius:
                    20px;

            }


            .upload-icon {

                width:
                    64px;

                height:
                    64px;

            }


            .upload-loader h2 {

                font-size:
                    20px;

            }

        }

    </style>

</head>


<body>


<div class="container">


    <!-- =====================================================
         TOP BAR
         ===================================================== -->

    <div class="top-bar">


        <div>

            <h1>
                File Upload Manager
            </h1>


            <div class="user-info">

                Logged in as:

                <strong>
                    <?= htmlspecialchars(
                        $loggedInName
                    ) ?>
                </strong>

            </div>

        </div>


        <form method="post">

            <button
                type="submit"
                name="logout"
                class="logout-btn"
            >

                Logout

            </button>

        </form>


    </div>


    <!-- =====================================================
         UPLOAD CARD
         ===================================================== -->

    <div class="upload-card">


        <h2>
            Upload File
        </h2>


        <form
            id="uploadForm"
            method="post"
            enctype="multipart/form-data"
        >


            <input
                type="file"
                name="file"
                id="fileInput"
                class="file-input"
                required
            >


            <button
                type="submit"
                name="uploadFile"
                value="1"
                id="uploadButton"
                class="upload-btn"
            >

                Upload File

            </button>


        </form>


        <?php if (
            isset($uploadMessage) &&
            $uploadMessage
        ): ?>

            <div
                class="message"
                style="
                    color:
                    <?= $uploadMessageColor ?>
                "
            >

                <?= htmlspecialchars(
                    $uploadMessage
                ) ?>

            </div>

        <?php endif; ?>


        <p
            style="
                font-size:12px;
                color:#777;
                margin-bottom:0;
            "
        >

            Maximum file size:
            <strong>
                500 MB
            </strong>

            <br>

            All file types are supported.

        </p>


    </div>


    <!-- =====================================================
         UPLOADED FILES
         ===================================================== -->

    <div class="files-card">


        <h2>
            Uploaded Files
        </h2>


        <?php if (
            !empty($uploadedFiles)
        ): ?>


            <table>


                <thead>

                    <tr>

                        <th>
                            #
                        </th>

                        <th>
                            File Name
                        </th>

                        <th>
                            Type
                        </th>

                        <th>
                            Size
                        </th>

                        <th>
                            Uploaded At
                        </th>

                        <th>
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php foreach (
                    $uploadedFiles
                    as $index => $file
                ): ?>


                    <tr>


                        <td>

                            <?= $index + 1 ?>

                        </td>


                        <td>

                            <div
                                class="file-name"
                            >

                                <?= htmlspecialchars(
                                    $file['original_name']
                                ) ?>

                            </div>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $file['file_type']
                                ?: 'Unknown'
                            ) ?>

                        </td>


                        <td>

                            <?= formatFileSize(
                                (int)
                                $file['file_size']
                            ) ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $file['uploaded_at']
                            ) ?>

                        </td>


                        <td>


                            <a
                                href="<?= htmlspecialchars(
                                    $file['file_path']
                                ) ?>"
                                target="_blank"
                                class="download-btn"
                                download
                            >

                                Download

                            </a>


                            <form
                                method="post"
                                style="
                                    display:inline;
                                "
                                onsubmit="
                                    return confirm(
                                        'Are you sure you want to delete this file?'
                                    );
                                "
                            >


                                <input
                                    type="hidden"
                                    name="uploadedId"
                                    value="<?= (int)
                                        $file['uploadedId'] ?>"
                                >


                                <button
                                    type="submit"
                                    name="deleteFile"
                                    class="delete-btn"
                                >

                                    Delete

                                </button>


                            </form>


                        </td>


                    </tr>


                <?php endforeach; ?>


                </tbody>


            </table>


        <?php else: ?>


            <div class="empty">


                <h3>
                    No files uploaded yet
                </h3>


                <p>
                    Upload your first file using
                    the form above.
                </p>


            </div>


        <?php endif; ?>


    </div>


</div>


<!-- =========================================================
     MODERN UPLOAD MODAL
     ========================================================= -->

<div
    id="uploadOverlay"
    class="upload-overlay"
>


    <div
        class="upload-loader"
        id="uploadLoader"
    >


        <!-- Upload Icon -->

        <div
            class="upload-icon"
            id="uploadIcon"
        >


            <svg
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
            >

                <path
                    d="
                    M12 16a1 1 0 0 0 1-1V6.41l2.29
                    2.3a1 1 0 0 0 1.42-1.42l-4-4a1
                    1 0 0 0-1.42 0l-4 4a1 1 0
                    1 0 1.42 1.42L11 6.41V15a1
                    1 0 0 0 1 1zM19 13a1 1 0
                    0 0-1 1v4H6v-4a1 1 0
                    0-2 0v5a1 1 0 0 0 1 1h14a1
                    1 0 0 0 1-1v-5a1 1 0
                    0 0-1-1z
                    "
                />

            </svg>


        </div>


        <h2
            id="uploadTitle"
        >

            Uploading File

        </h2>


        <p
            id="uploadStatus"
            class="upload-status"
        >

            Preparing your file...

        </p>


        <!-- Progress -->

        <div
            class="progress-container"
        >

            <div
                class="progress-bar"
                id="progressBar"
            ></div>

        </div>


        <!-- Percentage -->

        <div
            class="progress-info"
        >


            <div
                class="progress-left"
            >

                <div
                    class="progress-label"
                    id="progressLabel"
                >

                    Preparing...

                </div>


                <div
                    class="progress-details"
                    id="progressDetails"
                >

                    0 MB / 0 MB

                </div>


            </div>


            <span
                class="progress-percent"
                id="progressText"
            >

                0%

            </span>


        </div>


        <!-- Speed + Remaining -->

        <div
            class="upload-stats"
        >


            <div
                class="stat-box"
            >

                <div
                    class="stat-title"
                >

                    Speed

                </div>


                <div
                    class="stat-value"
                    id="uploadSpeed"
                >

                    0 MB/s

                </div>

            </div>


            <div
                class="stat-box"
            >

                <div
                    class="stat-title"
                >

                    Remaining

                </div>


                <div
                    class="stat-value"
                    id="timeRemaining"
                >

                    Calculating...

                </div>

            </div>


        </div>


        <!-- File -->

        <div
            id="selectedFile"
            class="selected-file"
        >

            Preparing file...

        </div>


    </div>


</div>


<script>

/* =========================================================
   ELEMENTS
   ========================================================= */

const uploadForm =
    document.getElementById(
        "uploadForm"
    );

const uploadOverlay =
    document.getElementById(
        "uploadOverlay"
    );

const uploadButton =
    document.getElementById(
        "uploadButton"
    );

const fileInput =
    document.getElementById(
        "fileInput"
    );

const progressBar =
    document.getElementById(
        "progressBar"
    );

const progressText =
    document.getElementById(
        "progressText"
    );

const progressLabel =
    document.getElementById(
        "progressLabel"
    );

const progressDetails =
    document.getElementById(
        "progressDetails"
    );

const uploadStatus =
    document.getElementById(
        "uploadStatus"
    );

const uploadTitle =
    document.getElementById(
        "uploadTitle"
    );

const selectedFile =
    document.getElementById(
        "selectedFile"
    );

const uploadSpeed =
    document.getElementById(
        "uploadSpeed"
    );

const timeRemaining =
    document.getElementById(
        "timeRemaining"
    );

const uploadIcon =
    document.getElementById(
        "uploadIcon"
    );


/* =========================================================
   MAXIMUM FILE SIZE
   ========================================================= */

const MAX_FILE_SIZE =
    500 * 1024 * 1024;


/* =========================================================
   FORMAT BYTES
   ========================================================= */

function formatBytes(
    bytes
) {

    if (
        !bytes ||
        bytes <= 0
    ) {

        return "0 B";

    }


    const units = [
        "B",
        "KB",
        "MB",
        "GB"
    ];


    const i =
        Math.floor(
            Math.log(bytes) /
            Math.log(1024)
        );


    const index =
        Math.min(
            i,
            units.length - 1
        );


    return (
        parseFloat(
            (
                bytes /
                Math.pow(
                    1024,
                    index
                )
            ).toFixed(2)
        )
        +
        " "
        +
        units[index]
    );

}


/* =========================================================
   FORMAT TIME
   ========================================================= */

function formatTime(
    seconds
) {

    if (
        !isFinite(seconds) ||
        seconds < 0
    ) {

        return "Calculating...";

    }


    seconds =
        Math.round(
            seconds
        );


    if (
        seconds < 60
    ) {

        return (
            seconds +
            " sec"
        );

    }


    const minutes =
        Math.floor(
            seconds / 60
        );


    const remainingSeconds =
        seconds % 60;


    if (
        minutes < 60
    ) {

        return (
            minutes +
            "m " +
            remainingSeconds +
            "s"
        );

    }


    const hours =
        Math.floor(
            minutes / 60
        );


    const remainingMinutes =
        minutes % 60;


    return (
        hours +
        "h " +
        remainingMinutes +
        "m"
    );

}


/* =========================================================
   FILE SELECTED
   ========================================================= */

fileInput.addEventListener(
    "change",
    function() {

        if (
            !this.files.length
        ) {

            return;

        }


        const file =
            this.files[0];


        selectedFile.innerText =
            file.name +
            " • " +
            formatBytes(
                file.size
            );


        /*
           Client-side 500 MB check.
        */

        if (
            file.size >
            MAX_FILE_SIZE
        ) {

            selectedFile.style.color =
                "#dc2626";

            selectedFile.innerText =
                "❌ File too large: " +
                formatBytes(
                    file.size
                ) +
                " — Maximum is 500 MB.";

        } else {

            selectedFile.style.color =
                "#64748b";

        }

    }
);


/* =========================================================
   UPLOAD FORM
   ========================================================= */

uploadForm.addEventListener(
    "submit",
    function(e) {

        e.preventDefault();


        if (
            !fileInput.files.length
        ) {

            return;

        }


        const file =
            fileInput.files[0];


        /*
           Client-side size validation.
        */

        if (
            file.size >
            MAX_FILE_SIZE
        ) {

            alert(
                "File is too large.\n\n" +
                "Selected: " +
                formatBytes(
                    file.size
                ) +
                "\n" +
                "Maximum: 500 MB"
            );

            return;

        }


        /*
           Disable upload button.
        */

        uploadButton.disabled =
            true;


        /*
           Show modal.
        */

        uploadOverlay.style.display =
            "flex";


        document.body.style.overflow =
            "hidden";


        /*
           Reset UI.
        */

        progressBar.style.width =
            "0%";


        progressText.innerText =
            "0%";


        progressLabel.innerText =
            "Uploading";


        progressDetails.innerText =
            "0 MB / " +
            formatBytes(
                file.size
            );


        uploadSpeed.innerText =
            "Calculating...";


        timeRemaining.innerText =
            "Calculating...";


        uploadTitle.innerText =
            "Uploading File";


        uploadStatus.innerText =
            "Uploading your file. Please keep this window open.";


        selectedFile.innerText =
            file.name +
            " • " +
            formatBytes(
                file.size
            );


        /*
           Reset icon.
        */

        uploadIcon.classList.remove(
            "success-icon",
            "error-icon"
        );


        /*
           Create FormData.
        */

        const formData =
            new FormData(
                uploadForm
            );


        /*
           IMPORTANT FIX:

           Make sure PHP receives
           $_POST['uploadFile'].
        */

        formData.set(
            "uploadFile",
            "1"
        );


        /*
           XMLHttpRequest.
        */

        const xhr =
            new XMLHttpRequest();


        /*
           Timing.
        */

        const startTime =
            Date.now();


        let lastLoaded =
            0;

        let lastTime =
            startTime;


        /* =================================================
           UPLOAD PROGRESS
           ================================================= */

        xhr.upload.addEventListener(
            "progress",
            function(event) {

                if (
                    !event.lengthComputable
                ) {

                    return;

                }


                const loaded =
                    event.loaded;


                const total =
                    event.total;


                const percent =
                    Math.round(
                        (
                            loaded /
                            total
                        ) *
                        100
                    );


                /*
                   Progress bar.
                */

                progressBar.style.width =
                    percent +
                    "%";


                /*
                   Percentage.
                */

                progressText.innerText =
                    percent +
                    "%";


                /*
                   MB progress.
                */

                progressDetails.innerText =
                    formatBytes(
                        loaded
                    ) +
                    " / " +
                    formatBytes(
                        total
                    );


                /*
                   Calculate speed.

                   Use average speed over
                   the complete upload.
                */

                const currentTime =
                    Date.now();


                const elapsedSeconds =
                    (
                        currentTime -
                        startTime
                    ) / 1000;


                if (
                    elapsedSeconds >
                    0
                ) {

                    const bytesPerSecond =
                        loaded /
                        elapsedSeconds;


                    uploadSpeed.innerText =
                        formatBytes(
                            bytesPerSecond
                        ) +
                        "/s";


                    /*
                       Remaining time.
                    */

                    const remainingBytes =
                        total -
                        loaded;


                    const remainingSeconds =
                        remainingBytes /
                        bytesPerSecond;


                    if (
                        isFinite(
                            remainingSeconds
                        )
                    ) {

                        timeRemaining.innerText =
                            formatTime(
                                remainingSeconds
                            );

                    }

                }


                /*
                   More detailed status.
                */

                progressLabel.innerText =
                    percent >= 100
                    ? "Finishing upload..."
                    : "Uploading";


                /*
                   Store last values.
                */

                lastLoaded =
                    loaded;

                lastTime =
                    currentTime;


                /*
                   When browser has sent
                   all data to the server.
                */

                if (
                    percent >= 100
                ) {

                    uploadTitle.innerText =
                        "Processing File";


                    uploadStatus.innerHTML =
                        '<span class="processing-spinner"></span>' +
                        'Upload sent. Waiting for the server to confirm...';


                    progressLabel.innerText =
                        "Processing";


                    timeRemaining.innerText =
                        "Processing...";

                }

            }
        );


        /* =================================================
           SERVER RESPONSE
           ================================================= */

        xhr.addEventListener(
            "load",
            function() {

                /*
                   HTTP status check.
                */

                if (
                    xhr.status < 200 ||
                    xhr.status >= 300
                ) {

                    showUploadError(
                        "Server returned HTTP " +
                        xhr.status +
                        "."
                    );

                    return;

                }


                /*
                   Parse JSON response.
                */

                let response;


                try {

                    response =
                        JSON.parse(
                            xhr.responseText
                        );

                } catch (error) {

                    showUploadError(
                        "The server returned an invalid response."
                    );

                    console.error(
                        xhr.responseText
                    );

                    return;

                }


                /*
                   SUCCESS
                */

                if (
                    response.success === true
                ) {

                    progressBar.style.width =
                        "100%";


                    progressText.innerText =
                        "100%";


                    progressDetails.innerText =
                        formatBytes(
                            file.size
                        ) +
                        " / " +
                        formatBytes(
                            file.size
                        );


                    progressLabel.innerText =
                        "Complete";


                    uploadSpeed.innerText =
                        "Finished";


                    timeRemaining.innerText =
                        "Done";


                    uploadTitle.innerText =
                        "Upload Complete";


                    uploadStatus.innerHTML =
                        "Your file has been uploaded successfully.";


                    /*
                       Change icon to success.
                    */

                    uploadIcon.classList.add(
                        "success-icon"
                    );


                    /*
                       Reload after short delay.
                    */

                    setTimeout(
                        function() {

                            window.location.reload();

                        },
                        900
                    );


                } else {

                    /*
                       Server reported failure.
                    */

                    showUploadError(
                        response.message ||
                        "Upload failed."
                    );

                }

            }
        );


        /* =================================================
           NETWORK ERROR
           ================================================= */

        xhr.addEventListener(
            "error",
            function() {

                showUploadError(
                    "A network error occurred during the upload."
                );

            }
        );


        /* =================================================
           TIMEOUT
           ================================================= */

        xhr.addEventListener(
            "timeout",
            function() {

                showUploadError(
                    "The upload timed out. Please try again."
                );

            }
        );


        /* =================================================
           ABORT
           ================================================= */

        xhr.addEventListener(
            "abort",
            function() {

                uploadTitle.innerText =
                    "Upload Cancelled";


                uploadStatus.innerText =
                    "The upload was cancelled.";


                progressLabel.innerText =
                    "Cancelled";


                closeUploadOverlay();

            }
        );


        /* =================================================
           OPEN REQUEST
           ================================================= */

        xhr.open(
            "POST",
            window.location.href,
            true
        );


        /*
           Give the browser plenty of time
           for large files.

           20 minutes.
        */

        xhr.timeout =
            20 * 60 * 1000;


        /*
           Send.
        */

        xhr.send(
            formData
        );

    }
);


/* =========================================================
   SHOW UPLOAD ERROR
   ========================================================= */

function showUploadError(
    message
) {

    uploadTitle.innerText =
        "Upload Failed";


    uploadStatus.innerText =
        message;


    progressLabel.innerText =
        "Failed";


    timeRemaining.innerText =
        "—";


    uploadIcon.classList.add(
        "error-icon"
    );


    /*
       Do not reload the page.

       Let user see the actual
       error message.
    */

    setTimeout(
        function() {

            closeUploadOverlay();

        },
        3000
    );

}


/* =========================================================
   CLOSE OVERLAY
   ========================================================= */

function closeUploadOverlay() {

    uploadOverlay.style.display =
        "none";


    document.body.style.overflow =
        "";


    uploadButton.disabled =
        false;

}


/* =========================================================
   PREVENT BACKGROUND CLOSE
   ========================================================= */

uploadOverlay.addEventListener(
    "click",
    function(e) {

        /*
           Don't close the upload modal
           accidentally.
        */

        if (
            e.target ===
            uploadOverlay
        ) {

            return;

        }

    }
);

</script>


</body>

</html>