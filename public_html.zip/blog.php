<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>BMI Calculator Guide - ToolNish</title>

  <meta name="description" content="Complete guide to BMI Calculator with formula, categories, advantages and usage steps.">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- HEADER / FOOTER SYSTEM -->
  <link rel="icon" href="../res/icon.png" type="image/png">
  <link rel="stylesheet" href="../res/header-footer.css">
  <script src="../res/header-footer.js" defer></script>

  <!-- GOOGLE FONT (PRO LOOK) -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <style>
    :root {
      --primary: #4e73df;
      --accent: #1cc88a;
      --bg: #f4f6fb;
      --card: #ffffff;
      --text: #1f2937;
    }

    body {
      margin: 0;
      font-family: 'Inter', sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.7;
    }

    /* ===== BLOG LAYOUT ===== */
    .blog-wrapper {
      max-width: 1050px;
      margin: auto;
      padding: 25px;
    }

    /* ===== HERO SECTION ===== */
    .hero {
      background: linear-gradient(135deg, var(--primary), var(--accent));
      color: white;
      padding: 60px 30px;
      border-radius: 18px;
      text-align: center;
      box-shadow: 0 10px 25px rgba(0,0,0,0.15);
      margin-bottom: 30px;
    }

    .hero h1 {
      font-size: 2.4rem;
      margin-bottom: 10px;
    }

    .hero p {
      opacity: 0.9;
      font-size: 1.1rem;
    }

    /* ===== CARD DESIGN ===== */
    .card {
      background: var(--card);
      padding: 25px;
      border-radius: 16px;
      margin-bottom: 22px;
      box-shadow: 0 6px 18px rgba(0,0,0,0.06);
      transition: 0.3s ease;
    }

    .card:hover {
      transform: translateY(-3px);
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }

    /* HEADINGS */
    h2 {
      color: var(--primary);
      font-size: 1.5rem;
      margin-bottom: 12px;
      border-left: 4px solid var(--accent);
      padding-left: 10px;
    }

    p {
      font-size: 1rem;
      text-align: justify;
    }

    ul {
      padding-left: 20px;
    }

    li {
      margin-bottom: 8px;
    }

    /* IMAGES */
    .img {
      width: 100%;
      border-radius: 14px;
      margin: 15px 0;
      box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    }

    /* HIGHLIGHT BOX */
    .highlight {
      background: linear-gradient(135deg, #e8f5e9, #f1fff4);
      border-left: 5px solid var(--accent);
      padding: 15px;
      border-radius: 12px;
      font-weight: 500;
    }

    /* BUTTON */
    .btn {
      display: inline-block;
      background: var(--accent);
      color: white;
      padding: 12px 18px;
      border-radius: 10px;
      text-decoration: none;
      font-weight: 600;
      transition: 0.3s;
      margin-top: 10px;
    }

    .btn:hover {
      background: #17a673;
      transform: scale(1.05);
    }

    /* RESPONSIVE */
    @media (max-width: 768px) {
      .hero h1 {
        font-size: 1.8rem;
      }

      .blog-wrapper {
        padding: 15px;
      }
    }
  </style>
</head>

<body>

<!-- HEADER -->
<div id="header"></div>

<div class="blog-wrapper">

  <!-- HERO -->
  <div class="hero">
    <h1>BMI Calculator Complete Guide</h1>
    <p>Understand your health, body weight, and BMI calculation in a simple way</p>
  </div>

  <!-- INTRO -->
  <div class="card">
    <h2>📌 What is BMI?</h2>

    <img class="img"
      src="https://images.unsplash.com/photo-1605296867304-46d5465a13f1"
      alt="BMI Health">

    <p>
      Body Mass Index (BMI) is a globally recognized health measurement used to determine whether a person has a
      healthy body weight according to height.
      It is widely used in hospitals, gyms, and fitness programs to estimate body condition.
    </p>

    <div class="highlight">
      ⚡ BMI is a screening tool, not a medical diagnosis.
    </div>
  </div>

  <!-- FORMULA -->
  <div class="card">
    <h2>📊 BMI Formula</h2>

    <img class="img"
      src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Body_mass_index_chart.svg/800px-Body_mass_index_chart.svg.png"
      alt="BMI Chart">

    <ul>
      <li>BMI = Weight (kg) ÷ Height² (meters)</li>
      <li>Example: 70 ÷ (1.75 × 1.75)</li>
    </ul>
  </div>

  <!-- CATEGORIES -->
  <div class="card">
    <h2>📈 BMI Categories</h2>

    <ul>
      <li>Underweight: below 18.5</li>
      <li>Normal: 18.5 – 24.9</li>
      <li>Overweight: 25 – 29.9</li>
      <li>Obese: 30+</li>
    </ul>
  </div>

  <!-- GUIDE -->
  <div class="card">
    <h2>⚙️ How to Use BMI Calculator</h2>

    <ul>
      <li>Open BMI Calculator tool</li>
      <li>Enter weight in KG</li>
      <li>Enter height in CM or meters</li>
      <li>Click Calculate</li>
      <li>Get instant result</li>
    </ul>

    <a class="btn" href="../bmiCalculator.html">Try BMI Calculator</a>
  </div>

  <!-- ADVANTAGES -->
  <div class="card">
    <h2>✨ Advantages</h2>
    <ul>
      <li>Fast and free health check</li>
      <li>No login required</li>
      <li>Mobile friendly</li>
      <li>Helps in fitness planning</li>
    </ul>
  </div>

  <!-- LIMITATIONS -->
  <div class="card">
    <h2>⚠️ Limitations</h2>
    <ul>
      <li>Does not measure body fat directly</li>
      <li>Not accurate for athletes</li>
      <li>Does not consider muscle mass</li>
    </ul>
  </div>

  <!-- FAQ -->
  <div class="card">
    <h2>❓ Frequently Asked Questions</h2>

    <p><b>Is BMI accurate?</b><br>It is a general health indicator, not exact measurement.</p>

    <p><b>Can athletes use BMI?</b><br>Yes, but results may vary due to muscle mass.</p>

    <p><b>Is BMI enough for health check?</b><br>No, it should be combined with other medical tests.</p>
  </div>

</div>

<!-- FOOTER -->
<div id="footer"></div>

</body>
</html>