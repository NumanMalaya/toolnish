   <?php
   ini_set('display_errors', 1);
   error_reporting(E_ALL);
   register_shutdown_function(function () {
       $e = error_get_last();
       if ($e) { echo "<pre>SHUTDOWN ERROR:\n"; print_r($e); echo "</pre>"; }
   });
   try {
       include __DIR__ . '/tcpPerforma.php';
   } catch (Throwable $t) {
       echo "<pre>CAUGHT:\n" . $t . "</pre>";
   }