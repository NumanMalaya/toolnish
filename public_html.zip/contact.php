<?php
// Handle form submission
$successMsg = $errorMsg = "";
$name = $email = $message = ""; // initialize variables

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $name = strip_tags(trim($_POST["name"]));
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $message = trim($_POST["message"]);

    if(empty($name) || empty($message) || !filter_var($email, FILTER_VALIDATE_EMAIL)){
        $errorMsg = "Please fill in all fields correctly.";
    } else {
        $to = "support@toolnish.com";
        $subject = "New Message from ToolNish Contact Form";
        $body = "Name: $name\nEmail: $email\n\nMessage:\n$message";
        $headers = "From: $name <$email>";

        if(mail($to, $subject, $body, $headers)){
            $successMsg = "Thank you! Your message has been sent successfully.";
            // Clear form fields after success
            $name = $email = $message = "";
        } else {
            $errorMsg = "Oops! Something went wrong. Please try again later.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Contact ToolNish - Get in Touch</title>
<link rel="icon" href="res/icon.png" type="image/png">

<!-- Header/Footer -->
<link rel="stylesheet" href="res/header-footer.css">
<script src="res/header-footer.js" defer></script>

<meta name="description" content="Contact ToolNish for support, feedback, or inquiries regarding our free online tools.">
<meta name="keywords" content="contact ToolNish, support ToolNish, online tools support, feedback ToolNish">
<link rel="canonical" href="https://toolnish.com/contact">

<!-- Open Graph -->
<meta property="og:title" content="Contact ToolNish">
<meta property="og:description" content="Get in touch with ToolNish for support and feedback.">
<meta property="og:url" content="https://toolnish.com/contact">
<meta property="og:type" content="website">
<meta property="og:image" content="https://toolnish.com/res/logo.png">
<meta name="google-adsense-account" content="ca-pub-5338649354805856">
<!-- Styles -->
<style>
:root{
  --bg:#f4f6fb;
  --card:#ffffff;
  --text:#222;
  --primary:#4e73df;
  --accent:#1cc88a;
  --shadow:rgba(0,0,0,0.08);
}
body.dark{
  --bg:#121212;
  --card:#1e1e1e;
  --text:#f5f5f5;
  --primary:#6c8cff;
  --accent:#20c997;
}

*{
  margin:0;
  padding:0;
  box-sizing:border-box;
  font-family:'Poppins', sans-serif;
}

body{
  background:var(--bg);
  color:var(--text);
  display:flex;
  flex-direction:column;
  min-height:100vh;
  transition:.3s;
}

.main-content{
  flex:1;
  max-width:1100px;
  margin:auto;
  padding:30px 20px;
}

.hero{
  text-align:center;
  margin-bottom:40px;
}
.hero img{
  width:150px;
  margin-bottom:15px;
}
.hero h2{
  font-size:1.8rem;
  font-weight:500;
  color:var(--primary);
}

.container{
  max-width:700px;
  margin:auto;
  background:var(--card);
  padding:40px 30px;
  border-radius:20px;
  box-shadow:0 8px 20px var(--shadow);
  transition:transform 0.3s, box-shadow 0.3s;
}
.container:hover{
  transform:translateY(-3px);
  box-shadow:0 12px 30px var(--shadow);
}

h1{
  text-align:center;
  color:var(--primary);
  margin-bottom:10px;
  font-size:2rem;
}
.sub{
  text-align:center;
  margin-bottom:30px;
  font-weight:400;
  color:var(--text);
  opacity:0.85;
}

.form-group{
  margin-bottom:20px;
}
input, textarea{
  width:100%;
  padding:14px 15px;
  border-radius:10px;
  border:1px solid #ddd;
  font-size:15px;
  transition:0.3s;
}
input:focus, textarea:focus{
  border-color:var(--primary);
  outline:none;
  box-shadow:0 0 0 3px rgba(78,115,223,0.15);
}

.submit{
  width:100%;
  background:var(--primary);
  color:white;
  padding:14px;
  border:none;
  border-radius:10px;
  cursor:pointer;
  font-weight:600;
  font-size:16px;
  transition:0.3s;
}
.submit:hover{
  background:var(--accent);
  transform:translateY(-2px);
}

.contact-info{
  margin-top:30px;
  text-align:center;
  font-size:15px;
  color:var(--text);
}
.contact-info p{
  margin-bottom:5px;
}
.contact-info a{
  color:var(--primary);
  font-weight:500;
  text-decoration:none;
}
.contact-info a:hover{
  text-decoration:underline;
}

.success-msg, .error-msg{
  text-align:center;
  padding:12px;
  margin-bottom:15px;
  border-radius:8px;
}
.success-msg{background:#d4edda;color:#155724;}
.error-msg{background:#f8d7da;color:#721c24;}

@media (max-width:768px){
  .container{
    padding:30px 20px;
  }
  h1{
    font-size:1.7rem;
  }
  .hero h2{
    font-size:1.5rem;
  }
}
</style>

</head>
<body>

<div class="main-content">

  <div class="hero">
    <img src="res/logo.png" alt="ToolNish Logo">
  </div>

  <div class="container">

    <h1>Contact Us</h1>
    <p class="sub">Have questions, feedback, or suggestions? Send us a message.</p>

    <!-- Success/Error Messages -->
    <?php if($successMsg): ?>
        <div class="success-msg"><?= $successMsg ?></div>
    <?php endif; ?>
    <?php if($errorMsg): ?>
        <div class="error-msg"><?= $errorMsg ?></div>
    <?php endif; ?>


    <!-- Form -->
    <form method="POST" action="">
      <div class="form-group">
        <!--<input type="text" name="name" placeholder="Your Name" required value="<?= isset($_POST['name']) ? htmlspecialchars($_POST['name']) : '' ?>">-->
        <input type="text" name="name" placeholder="Your Name" required value="<?= htmlspecialchars($name) ?>">
      </div>

      <div class="form-group">
        <!--<input type="email" name="email" placeholder="Your Email" required value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">-->
        <input type="email" name="email" placeholder="Your Email" required value="<?= htmlspecialchars($email) ?>">
      </div>

      <div class="form-group">
        <!--<textarea name="message" placeholder="Your Message" rows="6" required><?= isset($_POST['message']) ? htmlspecialchars($_POST['message']) : '' ?></textarea>-->
        <textarea name="message" placeholder="Your Message" rows="6" required><?= htmlspecialchars($message) ?></textarea>
      </div>

      <button type="submit" class="submit">Send Message</button>
    </form>

    <!-- Contact Info -->
    <div class="contact-info">
      <p>Or email us directly at:</p>
      <p><a href="mailto:support@toolnish.com">support@toolnish.com</a></p>
    </div>

  </div>

</div>

</body>
</html>